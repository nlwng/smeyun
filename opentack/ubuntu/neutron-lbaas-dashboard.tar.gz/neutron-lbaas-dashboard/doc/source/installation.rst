============
Installation
============

At the command line::

    $ pip install neutron-lbaas-dashboard

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv neutron-lbaas-dashboard
    $ pip install neutron-lbaas-dashboard
